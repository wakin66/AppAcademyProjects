def select_even_nums(arr)
    arr.select(&:even?)
end

def reject_puppies(arr)
    arr.reject {|x| x["age"] < 3}
end

def count_positive_subarrays(arr)
    arr.count {|x| x.inject(0, :+) > 0}
end

def aba_translate(str)
    new_str = ""
    str.each_char {|x| ("aeiou".include?(x)) ? (new_str += "#{x}b#{x}") : (new_str += x)}
    new_str
end

def aba_array(arr)
    arr.map {|x| aba_translate(x)}
end