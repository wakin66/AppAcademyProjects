def all_words_capitalized?(arr)
    arr.all? {|x| x[0] == x[0].upcase && x[1..-1] == x[1..-1].downcase}
end

def no_valid_url?(arr)
    suff = [".com",".net",".io",".org"]
    arr.none? {|x| suff.include?(x[-3..-1]) || suff.include?(x[-4..-1])}
end

def any_passing_students?(arr)
    arr.any? {|x| avg(*x[:grades]) > 75}
end

def avg (*nums)
    nums.inject(0, :+) / nums.size.to_f
end