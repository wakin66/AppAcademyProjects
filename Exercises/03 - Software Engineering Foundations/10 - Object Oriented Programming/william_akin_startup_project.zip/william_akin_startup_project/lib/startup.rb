require "employee"

class Startup
    attr_reader :name, :funding, :salaries, :employees

    def initialize(name,funding,salaries)
        @name = name
        @funding = funding
        @salaries = salaries
        @employees = []
    end

    def valid_title?(title)
        @salaries.each_key {|k| return true if title == k}
        false
    end

    def >(startup)
        (self.funding > startup.funding) ? (return true) : (return false)
    end

    def hire(name, title)
        valid_title?(title) ? (employees << Employee.new(name,title)) : (raise "The title you listed is invalid, please try again.")
    end

    def size
        @employees.length
    end

    def pay_employee(employee)
        if @funding >= @salaries[employee.title]
            employee.pay(@salaries[employee.title])
            @funding -= @salaries[employee.title]
        else
            raise "The Startup does not have enough funds to pay this employee."
        end
    end

    def payday
        @employees.each {|x| pay_employee(x)}
    end

    def average_salary
        total_salary = 0
        @employees.each {|x| total_salary += @salaries[x.title]}
        total_salary /= @employees.length
    end

    def close
        @employees = []
        @funding = 0
    end

    def acquire(startup)
        @funding += startup.funding
        @salaries = startup.salaries.merge!(@salaries)
        startup.employees.each {|x| @employees << x}
        startup.close
    end
end
