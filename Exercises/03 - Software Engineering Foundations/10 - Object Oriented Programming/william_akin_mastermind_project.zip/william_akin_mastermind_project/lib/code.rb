class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

  attr_reader :pegs

  def self.valid_pegs?(arr)
    arr.all? {|x| POSSIBLE_PEGS.include?(x.upcase)}
  end

  def initialize(arr)
    Code.valid_pegs?(arr) ? (@pegs = arr.map {|x| x.upcase}) : (raise "The pegs are invalid.")
  end

  def self.random(len)
    arr = []
    len.times do 
      x = rand(1..4)
      case x
        when 1
          arr << "R"
        when 2
          arr << "G"
        when 3
          arr << "B"
        when 4
          arr << "Y"
      end
    end
    Code.new(arr)
  end

  def self.from_string(str)
    arr = []
    str.each_char {|x| arr << x}
    Code.new(arr)
  end

  def [](idx)
    @pegs[idx]
  end

  def length
    @pegs.length
  end

  def num_exact_matches(guess)
    count = 0
    @pegs.each_with_index {|x,idx| count +=1 if x == guess[idx]}
    count
  end

  def num_near_matches(guess)
    count = 0
    (0...guess.length).each {|idx| count += 1 if self[idx] != guess[idx] && self.pegs.include?(guess[idx])}
    count
  end

  def ==(code)
    return false if code.length != self.length
    @pegs.each_with_index {|x,idx| return false if x != code[idx]}
    true
  end
end