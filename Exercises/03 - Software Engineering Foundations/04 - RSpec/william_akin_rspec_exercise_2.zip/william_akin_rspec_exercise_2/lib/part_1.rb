def partition(arr, num)
    arr_1 = []
    arr_2 = []
    arr.each {|x| (x < num) ? (arr_1 << x) : (arr_2 << x)}
    [arr_1,arr_2]
end

def merge(hash_1,hash_2)
    hash = Hash.new
    hash_1.each {|k,v| hash[k] = v}
    hash_2.each {|k,v| hash[k] = v}
    return hash
end

def censor(str,arr)
    sent = str.split
    vow = "aeiou"
    sent.each_with_index do |x, idx|
        if arr.include?(x.downcase)
            word = ""
            x.each_char {|y| vow.include?(y.downcase) ? (word += "*") : (word += y)}
            sent[idx] = word
        else
        end
    end
    sent.join(" ")
end

def power_of_two?(num)
    return true if num == 1
    return false if num % 2 != 0
    test = 2
    while test < num
        test *= 2
    end
    (test == num) ? (return true) : (return false)
end