def palindrome?(str)
    idx_1 = 0
    idx_2 = str.length - 1
    while idx_1 < idx_2
        return false if str[idx_1] != str[idx_2]
        idx_1 += 1
        idx_2 -= 1
    end
    true
end

def substrings(str)
    arr = []
    idx_1 = 0
    idx_2 = 0
    while idx_1 < str.length
        while idx_2 < str.length
            arr << str[idx_1..idx_2]
            idx_2 += 1
        end
        idx_1 += 1
        idx_2 = idx_1
    end
    return arr
end

def palindrome_substrings(str)
    arr = []
    arr = substrings(str)
    arr.select! {|x| x.length > 1 && palindrome?(x)}
    arr
end