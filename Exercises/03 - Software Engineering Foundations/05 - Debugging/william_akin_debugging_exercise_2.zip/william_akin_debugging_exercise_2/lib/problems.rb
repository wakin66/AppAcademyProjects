# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.
require "byebug"

def largest_prime_factor(num)
    factors = factors(num)
    prime_factors = factors.select {|x| is_prime?(x)}
    prime_factors[-1]
end

def factors(num)
    factors = []
    (1..num).each {|x| factors << x if num % x == 0}
    factors
end

def is_prime?(num)
    return false if num < 2
    (2...num).each {|x| return false if num % x == 0}
    true
end

def unique_chars?(str)
    chars = Hash.new(0)
    str.each_char {|x| chars[x] +=1}
    chars.each_value {|y| return false if y > 1}
    true
end

def dupe_indices(arr)
    hash = Hash.new() {Array.new}
    arr.each_with_index {|x, idx| hash[x] = hash[x].push(idx)}
    hash.select! {|k,v| v.length > 1}
    hash
end

def ana_array(arr_1, arr_2)
    count_1 = Hash.new(0)
    count_2 = Hash.new(0)
    return false if arr_1.length != arr_2.length
    arr_1.each {|x| count_1[x] +=1}
    arr_2.each {|x| count_2[x] +=1}
    count_1 == count_2
end