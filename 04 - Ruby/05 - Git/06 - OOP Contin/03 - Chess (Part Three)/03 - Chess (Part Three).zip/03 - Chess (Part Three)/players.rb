require_relative 'players/player.rb'
require_relative 'players/human_player.rb'
require_relative 'players/computer_player.rb'