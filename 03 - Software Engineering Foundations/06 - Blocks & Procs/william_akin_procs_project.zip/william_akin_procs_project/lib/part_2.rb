def reverser(str, &prc)
    new_str = ""
    str.each_char {|x| new_str = x + new_str}
    prc.call(new_str)
end

def word_changer(str, &prc)
    words = []
    str.split.each {|x| words << prc.call(x)}
    words.join(" ")
end

def greater_proc_value(num, prc_1, prc_2)
    (prc_1.call(num) > prc_2.call(num)) ? prc_1.call(num) : prc_2.call(num)
end

def and_selector(arr, prc_1, prc_2)
    arr.select {|x| prc_1.call(x) && prc_2.call(x)}
end

def alternating_mapper(arr, prc_1, prc_2)
    new_arr = []
    arr.each_with_index {|x,idx| idx.even? ? (new_arr << prc_1.call(x)) : (new_arr << prc_2.call(x))}
    new_arr
end