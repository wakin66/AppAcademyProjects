def my_map(arr, &prc)
    new_arr = []
    arr.each {|x| new_arr << prc.call(x)}
    new_arr
end

def my_select(arr, &prc)
    arr.delete_if {|x| !prc.call(x)}
end

def my_count(arr, &prc)
    count = 0
    arr.each {|x| count += 1 if prc.call(x)}
    count
end

def my_any?(arr, &prc)
    (my_count(arr, &prc) > 0) ? true : false
end

def my_all?(arr, &prc)
    (my_count(arr, &prc) == arr.length) ? true : false
end

def my_none?(arr, &prc)
    (my_count(arr, &prc) == 0) ? true : false
end