require_relative "room"

class Hotel
    def initialize(name, rooms)
        @name = name
        @rooms = {}
        rooms.each {|k,v| @rooms[k] = Room.new(v)}
    end

    def name
        words = []
        @name.split.each {|x| words << "#{x[0].upcase}#{x[1..-1]}"}
        words.join(" ")
    end

    def rooms
        @rooms
    end

    def room_exists?(name)
        @rooms.include?(name) ? true : false
    end

    def check_in(person, room)
        room_exists?(room) ? (@rooms[room].add_occupant(person) ? (print "check in successful") : (print "sorry, room is full")) : (print "sorry, room does not exist")
    end

    def has_vacancy?
        @rooms.each_value {|v| return true if !v.full?}
        false
    end

    def list_rooms
        @rooms.each {|k,v| puts "#{k} : #{v.available_space}"}
    end
end