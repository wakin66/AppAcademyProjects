# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array
  def span
    return nil if self.length == 0
    min = 0
    max = 0
    self.each_with_index do |x, idx|
        if idx == 0
            min = x
            max = x
        end
        min = x if x < min
        max = x if x > max
    end
    max - min
  end

  def average
    return nil if self.length == 0
    self.sum / self.length.to_f
  end

  def median
    return nil if self.length == 0
    if self.length % 2 == 1
        self.sort[self.length / 2]
    else
        idx_2 = self.length / 2
        idx_1 = idx_2 - 1
        [self.sort[idx_1],self.sort[idx_2]].average
    end
  end

  def counts
    count = Hash.new(0)
    self.each {|x| count[x] += 1}
    count
  end

  def my_count(value)
    count = 0
    self.each {|x| count +=1 if x == value}
    count
  end

  def my_index(value)
    self.each_with_index {|x, idx| return idx if x == value}
    nil
  end

  def my_uniq
    new_arr = []
    self.each {|x| new_arr << x if !new_arr.include?(x)}
    new_arr
  end

  def my_transpose
    new_arr = []
    self.length.times {new_arr << []}
    self.each {|x| x.each_with_index {|y, idx| new_arr[idx] << y}}
    new_arr
  end
end
