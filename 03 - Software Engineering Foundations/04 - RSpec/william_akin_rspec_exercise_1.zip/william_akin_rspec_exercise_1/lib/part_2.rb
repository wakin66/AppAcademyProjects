def hipsterfy(str)
    vow = "aeiou"
    return str if str.each_char.none? {|x| vow.include?(x)}
    rmv = 0
    str.each_char.with_index {|x,idx| rmv = idx if vow.include?(x)}
    return str[1..-1] if rmv == 0
    return str[0...-1] if rmv == str.length-1
    str[0...rmv] + str[rmv+1..-1]
end

def vowel_counts(str)
    hash = Hash.new(0)
    vow = "aeiou"
    str.each_char {|x| hash[x.downcase] += 1 if vow.include?(x.downcase)}
    return hash
end

def caesar_cipher(str, num)
    alpha = "abcdefghijklmnopqrstuvwxyz"
    cipher = ""
    str.each_char {|x| (alpha.include?(x)) ? (cipher += alpha[(alpha.index(x)+num)%26]) : (cipher += x)}
    cipher
end