# Write a method, least_common_multiple, that takes in two numbers and returns the smallest number that is a mutiple 
# of both of the given numbers
def least_common_multiple(num_1, num_2)
    x = 0
    flag = false
    while !flag
        x += 1
        flag = true if (x % num_1 == 0) && (x % num_2 == 0)
    end
    x
end


# Write a method, most_frequent_bigram, that takes in a string and returns the two adjacent letters that appear the
# most in the string.
def most_frequent_bigram(str)
    hash = Hash.new(0)
    count = 0
    (0...str.length-1).each {|x| hash[str[x..x+1]] += 1}
    hash.each_value {|v| count = v if v > count}
    hash.key(count)
end


class Hash
    # Write a method, Hash#inverse, that returns a new hash where the key-value pairs are swapped
    def inverse
        self.invert     # I already knew about the #invert method, so I used it. However, I thought
    end                 # that since it's an easy method to create I wrote it in the comment below

    # def inverse
    #     hash = {}
    #     self.each {|k,v| hash[v] = k}
    #     hash
    # end
end


class Array
    # Write a method, Array#pair_sum_count, that takes in a target number
    # returns the number of pairs of elements that sum to the given target
    def pair_sum_count(num)
        count = 0
        self.each_with_index do |x, idx_1|
            return count if idx_1 == self.length - 1
            (idx_1+1...self.length).each do |y|
                count += 1 if x + self[y] == num
            end
        end
    end


    # Write a method, Array#bubble_sort, that takes in an optional proc argument.
    # When given a proc, the method should sort the array according to the proc.
    # When no proc is given, the method should sort the array in increasing order.
    def bubble_sort(&prc)
        prc ||= Proc.new {|x,y| x <=> y}
        sorted = false
        while !sorted
            sorted = true
            (0...self.length-1).each do |idx|
               if prc.call(self[idx],self[idx+1]) == 1
                self[idx], self[idx + 1] = self[idx + 1], self[idx]
                sorted = false
               end
            end
        end
        self
    end
end
