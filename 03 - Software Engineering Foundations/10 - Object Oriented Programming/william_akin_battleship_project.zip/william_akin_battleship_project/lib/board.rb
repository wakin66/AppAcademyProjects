class Board
    attr_reader :size

    def initialize(num)
    @grid = Array.new(num) {Array.new(num) {:N}}
    @size = num * num
    end

    def [](pos)
        @grid[pos[0]][pos[1]]
    end

    def []=(pos, val)
        @grid[pos[0]][pos[1]] = val
    end

    def num_ships
        count = 0
        @grid.each {|x| x.each{|y| count += 1 if y == :S}}
        count
    end

    def attack(pos)
        if self[pos] == :S 
            self[pos] = :H
            puts "You sunk my battleship!"
            return true
        else
            self[pos] = :X
            return false
        end
    end

    def place_random_ships
        (@size / 4).times do
            flag = false
            while !flag
                idx_1 = rand(0...@grid.length)
                idx_2 = rand(0...@grid.length)
                if @grid[idx_1][idx_2] != :S
                    @grid[idx_1][idx_2] = :S
                    flag = true
                end
            end
        end
    end

    def hidden_ships_grid
        hidden = Array.new(@grid.length) {Array.new(@grid.length) {:N}}
        hidden.each_with_index {|x, idx_1| x.each_with_index{|y, idx_2| hidden[idx_1][idx_2] = @grid[idx_1][idx_2] if @grid[idx_1][idx_2] != :S}}
        hidden
    end

    def self.print_grid(grid)
        grid.each do |x|
            x.each_with_index {|y, idx| (idx != x.length-1) ? (print "#{y} ") : (print y)}
            puts
        end
    end

    def cheat
        Board.print_grid(@grid)
    end

    def print
        Board.print_grid(self.hidden_ships_grid)
    end
end