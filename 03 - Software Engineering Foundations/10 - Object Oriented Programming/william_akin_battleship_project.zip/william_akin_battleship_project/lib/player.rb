class Player
    def get_move
        arr = []
        print "enter a position"
        gets.chomp.split.each {|x| arr << x.to_i}
        arr
    end
end